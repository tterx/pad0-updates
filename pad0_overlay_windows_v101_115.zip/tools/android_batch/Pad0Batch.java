import java.io.*;
import java.net.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Local shell-owned input executor. No APK, root, network service or new DOWN on cancel. */
public final class Pad0Batch {
    static final int MAGIC=0x50414439;
    final Object injector,properties,coordinates;
    final Method inject,obtain,recycle,setSource,setDisplay,uptime;
    final AtomicBoolean cancelled=new AtomicBoolean(false),busy=new AtomicBoolean(false);
    volatile boolean pressed=false;
    long downTime;
    int lastX,lastY,width,height;
    DataOutputStream output;
    Pad0Batch() throws Exception {
        Class<?> motion=Class.forName("android.view.MotionEvent");
        Class<?> input=Class.forName("android.view.InputEvent");
        Object binder=Class.forName("android.os.ServiceManager").getMethod("getService",String.class).invoke(null,"input");
        Class<?> stub=Class.forName("android.hardware.input.IInputManager$Stub");
        injector=stub.getMethod("asInterface",Class.forName("android.os.IBinder")).invoke(null,binder);
        Method selected=null;
        for(Method method:injector.getClass().getMethods())
            if(method.getName().equals("injectInputEvent") && method.getParameterTypes().length==2)selected=method;
        if(selected==null)throw new IOException("injectInputEvent unavailable");
        inject=selected;inject.setAccessible(true);
        Class<?> property=Class.forName("android.view.MotionEvent$PointerProperties");
        Class<?> coordinate=Class.forName("android.view.MotionEvent$PointerCoords");
        properties=Array.newInstance(property,1);coordinates=Array.newInstance(coordinate,1);
        Object pointer=property.newInstance();property.getField("id").setInt(pointer,0);
        property.getField("toolType").setInt(pointer,1); // TOOL_TYPE_FINGER
        Array.set(properties,0,pointer);Array.set(coordinates,0,coordinate.newInstance());
        obtain=motion.getMethod("obtain",long.class,long.class,int.class,int.class,properties.getClass(),coordinates.getClass(),int.class,int.class,float.class,float.class,int.class,int.class,int.class,int.class);
        recycle=motion.getMethod("recycle");setSource=motion.getMethod("setSource",int.class);
        setDisplay=motion.getMethod("setDisplayId",int.class);
        uptime=Class.forName("android.os.SystemClock").getMethod("uptimeMillis");
    }
    synchronized void event(int action,int x,int y,List<long[]> trace,long start) throws Exception {
        if((action==0||action==2)&&cancelled.get())throw new InterruptedException("cancelled");
        long now=((Number)uptime.invoke(null)).longValue();
        if(action==0){downTime=now;pressed=true;}
        if(downTime==0)downTime=now;
        Object position=Array.get(coordinates,0);Class<?> coordinate=position.getClass();
        coordinate.getField("x").setFloat(position,(float)x);coordinate.getField("y").setFloat(position,(float)y);
        coordinate.getField("pressure").setFloat(position,action==1||action==3?0f:1f);coordinate.getField("size").setFloat(position,1f);
        Object e=obtain.invoke(null,downTime,now,action,1,properties,coordinates,0,0,1f,1f,0,0,0x1002,0);
        try {
            setSource.invoke(e,0x1002);setDisplay.invoke(e,0);
            // WAIT_FOR_FINISH: success means Android finished dispatching this event.
            if(!Boolean.TRUE.equals(inject.invoke(injector,e,2)))throw new IOException("Android rejected touch "+action);
            lastX=x;lastY=y;
            if(action==1)pressed=false;
            if(trace!=null)trace.add(new long[]{action,x,y,(System.nanoTime()-start)/1000});
        } finally {recycle.invoke(e);}
    }
    synchronized void release(boolean cancel,int x,int y,List<long[]> trace,long start) throws Exception {
        if(cancel)event(3,x,y,trace,start);
        event(1,x,y,trace,start);
    }
    void pause(long nanos) throws InterruptedException {
        long end=System.nanoTime()+nanos;
        while(true){
            if(cancelled.get())throw new InterruptedException("cancelled");
            long left=end-System.nanoTime();if(left<=0)return;
            long part=Math.min(left,5000000L);Thread.sleep(part/1000000L,(int)(part%1000000L));
        }
    }
    synchronized void reply(int seq,int status,List<long[]> trace,String message) throws IOException {
        synchronized(output){
            output.writeInt(seq);output.writeInt(status);output.writeInt(trace.size());
            for(long[] row:trace){output.writeInt((int)row[0]);output.writeInt((int)row[1]);output.writeInt((int)row[2]);output.writeLong(row[3]);}
            output.writeUTF(message);output.flush();
        }
    }
    void gesture(final int seq,final int[][] points,final int hold,final int settle,final int maxMs,final int stepUs) {
        if(!busy.compareAndSet(false,true)){
            try{reply(seq,2,Collections.<long[]>emptyList(),"gesture already active");}catch(IOException ignored){}
            return;
        }
        cancelled.set(false);
        new Thread(new Runnable(){public void run(){
            List<long[]> trace=new ArrayList<long[]>();long start=System.nanoTime();int status=0;String message="delivered";
            try {
                event(0,points[0][0],points[0][1],trace,start);pause(hold*1000000L);
                for(int i=1;i<points.length;i++)for(int part=1;part<=4;part++){
                    pause(stepUs*1000L);
                    if((System.nanoTime()-start)/1000000L>maxMs-80)throw new IOException("gesture time budget exceeded");
                    int x=(int)Math.round(points[i-1][0]+(points[i][0]-points[i-1][0])*part/4.0);
                    int y=(int)Math.round(points[i-1][1]+(points[i][1]-points[i-1][1])*part/4.0);
                    event(2,x,y,trace,start);
                }
                pause(settle*1000000L);
            } catch(InterruptedException e){status=1;message="cancelled";}
              catch(Exception e){status=2;message=e.toString();}
            finally {
                try{release(status!=0||cancelled.get(),lastX,lastY,trace,start);}
                catch(Exception e){status=2;message="release failed: "+e;}
                busy.set(false);
                try{reply(seq,status,trace,message);}catch(IOException ignored){}
            }
        }},"pad0-gesture").start();
    }
    void serve(Socket socket,String token) throws Exception {
        socket.setTcpNoDelay(true);DataInputStream in=new DataInputStream(socket.getInputStream());
        output=new DataOutputStream(socket.getOutputStream());
        if(in.readInt()!=MAGIC||!token.equals(in.readUTF()))throw new IOException("session mismatch");
        width=in.readInt();height=in.readInt();if(width<1||height<1||width>16384||height>16384)throw new IOException("invalid size");
        output.writeInt(MAGIC);output.flush();
        try{while(true){
            int command=in.readInt(),seq=in.readInt();
            if(command==1){
                int count=in.readInt(),hold=in.readInt(),settle=in.readInt(),max=in.readInt(),step=in.readInt();
                if(count<1||count>66||hold<0||hold>1000||settle<0||settle>1000||max<100||max>15000||step<1000||step>100000)throw new IOException("invalid gesture");
                int[][] points=new int[count][2];
                for(int i=0;i<count;i++){
                    points[i][0]=in.readInt();points[i][1]=in.readInt();
                    if(points[i][0]<0||points[i][0]>=width||points[i][1]<0||points[i][1]>=height)throw new IOException("point outside display");
                }
                gesture(seq,points,hold,settle,max,step);
            }else if(command==2){
                int x=in.readInt(),y=in.readInt();cancelled.set(true);
                List<long[]> trace=new ArrayList<long[]>();long start=System.nanoTime();int status=0;String message="released";
                try{release(true,pressed?lastX:x,pressed?lastY:y,trace,start);}catch(Exception e){status=2;message=e.toString();}
                reply(seq,status,trace,message);
            }else throw new IOException("unknown command");
        }}catch(EOFException expected){}finally{cancelled.set(true);if(pressed)release(true,lastX,lastY,null,System.nanoTime());}
    }
    public static void main(String[] args) throws Exception {
        Pad0Batch app=new Pad0Batch();int port=Integer.parseInt(args[0]);
        try(ServerSocket server=new ServerSocket(port,1,InetAddress.getByName("127.0.0.1"));Socket socket=server.accept()){
            app.serve(socket,args[1]);
        }
    }
}
