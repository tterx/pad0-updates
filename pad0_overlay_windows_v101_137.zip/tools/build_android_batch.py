"""Rebuild the embedded, first-party Android executor; Java compiler + pinned D8.
Usage: python tools/build_android_batch.py --r8 /path/to/r8-8.3.37.jar --check
Downloads only when --r8 is omitted; verifies the pinned official artifact.
"""
import argparse,ast,base64,hashlib,io,subprocess,tempfile,urllib.request,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
R8_URL='https://dl.google.com/dl/android/maven2/com/android/tools/r8/8.3.37/r8-8.3.37.jar'
R8_SHA256='59753e70a74f918389cc87f1b7d66b5c0862932559167425708ded159e3de439'

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--r8',type=Path);parser.add_argument('--check',action='store_true');parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    with tempfile.TemporaryDirectory() as temp:
        work=Path(temp);r8=args.r8 or work/'r8.jar'
        if args.r8 is None:r8.write_bytes(urllib.request.urlopen(R8_URL,timeout=60).read())
        if hashlib.sha256(r8.read_bytes()).hexdigest()!=R8_SHA256:raise RuntimeError('D8 artifact checksum mismatch')
        classes=work/'classes';dex=work/'dex';classes.mkdir();dex.mkdir()
        subprocess.run(['java','com.sun.tools.javac.Main','-source','8','-target','8','-Xlint:-options','-d',str(classes),str(ROOT/'tools/android_batch/Pad0Batch.java')],check=True)
        subprocess.run(['java','-cp',str(r8),'com.android.tools.r8.D8','--min-api','26','--output',str(dex),*map(str,classes.glob('*.class'))],check=True)
        output=io.BytesIO()
        with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as archive:
            info=zipfile.ZipInfo('classes.dex',(2026,10,19,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,(dex/'classes.dex').read_bytes())
        data=output.getvalue();digest=hashlib.sha256(data).hexdigest()
        if args.check:
            tree=ast.parse((ROOT/'pad0_overlay.py').read_text())
            values={node.targets[0].id:ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and node.targets[0].id in ('ANDROID_BATCH_SHA256','ANDROID_BATCH_B85')}
            assert digest==values['ANDROID_BATCH_SHA256'] and data==base64.b85decode(values['ANDROID_BATCH_B85'])
            print('PASS reproducible embedded executor:',digest)
        if args.output:args.output.write_bytes(data)
if __name__=='__main__':main()
