import java.io.*;
import java.net.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Local shell-owned input executor. No APK, root, network service or new DOWN on cancel. */
public final class Pad0Batch {
    static final int MAGIC=0x50414439;
    final Object injector,properties,coordinates;
    final Method inject,obtain,recycle,setSource,setDisplay,uptime;
    final AtomicBoolean cancelled=new AtomicBoolean(false),busy=new AtomicBoolean(false);
    volatile boolean pressed=false;
    long downTime;
    volatile int activeGesture=0;
    volatile long gestureStart=0,leaseEnd=0;
    final int touchDevice;
    int lastX,lastY,width,height;
    DataOutputStream output;
    Pad0Batch() throws Exception {
        Class<?> devices=Class.forName("android.view.InputDevice");
        int selectedDevice=0;
        // Match Android's input touchscreen command, rather than inventing a
        // second device 0 stream alongside the emulator's real touchscreen.
        for(int id:(int[])devices.getMethod("getDeviceIds").invoke(null)){
            Object device=devices.getMethod("getDevice",int.class).invoke(null,id);
            if(device!=null&&Boolean.TRUE.equals(devices.getMethod("supportsSource",int.class).invoke(device,0x1002))){selectedDevice=id;break;}
        }
        touchDevice=selectedDevice;
        Class<?> motion=Class.forName("android.view.MotionEvent");
        Class<?> input=Class.forName("android.view.InputEvent");
        Object binder=Class.forName("android.os.ServiceManager").getMethod("getService",String.class).invoke(null,"input");
        Class<?> stub=Class.forName("android.hardware.input.IInputManager$Stub");
        injector=stub.getMethod("asInterface",Class.forName("android.os.IBinder")).invoke(null,binder);
        Method selected=null;
        for(Method method:injector.getClass().getMethods())
            if(method.getName().equals("injectInputEvent") && method.getParameterTypes().length==2)selected=method;
        if(selected==null)throw new IOException("injectInputEvent unavailable");
        inject=selected;inject.setAccessible(true);
        Class<?> property=Class.forName("android.view.MotionEvent$PointerProperties");
        Class<?> coordinate=Class.forName("android.view.MotionEvent$PointerCoords");
        properties=Array.newInstance(property,1);coordinates=Array.newInstance(coordinate,1);
        Object pointer=property.newInstance();property.getField("id").setInt(pointer,0);
        property.getField("toolType").setInt(pointer,1); // TOOL_TYPE_FINGER
        Array.set(properties,0,pointer);Array.set(coordinates,0,coordinate.newInstance());
        obtain=motion.getMethod("obtain",long.class,long.class,int.class,int.class,properties.getClass(),coordinates.getClass(),int.class,int.class,float.class,float.class,int.class,int.class,int.class,int.class);
        recycle=motion.getMethod("recycle");setSource=motion.getMethod("setSource",int.class);
        setDisplay=motion.getMethod("setDisplayId",int.class);
        uptime=Class.forName("android.os.SystemClock").getMethod("uptimeMillis");
    }
    synchronized void event(int action,int x,int y,List<long[]> trace,long start) throws Exception {
        pointerEvent(action,x,y,trace,start,0x1002,1);
    }
    synchronized void pointerEvent(int action,int x,int y,List<long[]> trace,long start,int source,int tool) throws Exception {
        pointerEventDevice(action,x,y,trace,start,source,tool,touchDevice);
    }
    synchronized void pointerEventDevice(int action,int x,int y,List<long[]> trace,long start,int source,int tool,int device) throws Exception {
        if((action==0||action==2)&&cancelled.get())throw new InterruptedException("cancelled");
        long now=((Number)uptime.invoke(null)).longValue();
        if(action==0){downTime=now;pressed=true;}
        if(downTime==0)downTime=now;
        Object position=Array.get(coordinates,0);Class<?> coordinate=position.getClass();
        coordinate.getField("x").setFloat(position,(float)x);coordinate.getField("y").setFloat(position,(float)y);
        coordinate.getField("pressure").setFloat(position,tool==3||action==1||action==3?0f:1f);coordinate.getField("size").setFloat(position,1f);
        Object pointer=Array.get(properties,0);pointer.getClass().getField("toolType").setInt(pointer,tool);
        Object e=obtain.invoke(null,downTime,now,action,1,properties,coordinates,0,0,1f,1f,device,0,source,0);
        try {
            setSource.invoke(e,source);setDisplay.invoke(e,0);
            // WAIT_FOR_FINISH: success means Android finished dispatching this event.
            if(!Boolean.TRUE.equals(inject.invoke(injector,e,2)))throw new IOException("Android rejected touch "+action);
            lastX=x;lastY=y;
            if(action==1)pressed=false;
            if(trace!=null)trace.add(new long[]{action,x,y,(System.nanoTime()-start)/1000});
        } finally {recycle.invoke(e);}
    }
    synchronized void release(boolean cancel,int x,int y,List<long[]> trace,long start) throws Exception {
        boolean cancelledOwner=false;
        Exception cancelError=null;
        if(cancel){
            try{event(3,x,y,trace,start);cancelledOwner=true;pressed=false;}
            catch(Exception e){cancelError=e;}
        }
        try{event(1,x,y,trace,start);}
        catch(Exception e){
            // A confirmed CANCEL already ended OUR stream. Android may reject
            // the following unmatched UP; a rejected active UP alone is fatal.
            if(!cancelledOwner){if(cancelError!=null)e.addSuppressed(cancelError);throw e;}
        }
    }
    void pause(long nanos) throws InterruptedException {
        long end=System.nanoTime()+nanos;
        while(true){
            if(cancelled.get())throw new InterruptedException("cancelled");
            long left=end-System.nanoTime();if(left<=0)return;
            long part=Math.min(left,5000000L);Thread.sleep(part/1000000L,(int)(part%1000000L));
        }
    }
    synchronized void reply(int seq,int status,List<long[]> trace,String message) throws IOException {
        synchronized(output){
            output.writeInt(seq);output.writeInt(status);output.writeInt(trace.size());
            for(long[] row:trace){output.writeInt((int)row[0]);output.writeInt((int)row[1]);output.writeInt((int)row[2]);output.writeLong(row[3]);}
            output.writeUTF(message);output.flush();
        }
    }
    void gesture(final int seq,final int[][] points,final int hold,final int settle,final int maxMs,final int stepUs) {
        if(pressed||!busy.compareAndSet(false,true)){
            try{reply(seq,2,Collections.<long[]>emptyList(),"gesture already active");}catch(IOException ignored){}
            return;
        }
        cancelled.set(false);
        new Thread(new Runnable(){public void run(){
            List<long[]> trace=new ArrayList<long[]>();long start=System.nanoTime();int status=0;String message="delivered";
            try {
                event(0,points[0][0],points[0][1],trace,start);pause(hold*1000000L);
                for(int i=1;i<points.length;i++)for(int part=1;part<=4;part++){
                    pause(stepUs*1000L);
                    if((System.nanoTime()-start)/1000000L>maxMs-80)throw new IOException("gesture time budget exceeded");
                    int x=(int)Math.round(points[i-1][0]+(points[i][0]-points[i-1][0])*part/4.0);
                    int y=(int)Math.round(points[i-1][1]+(points[i][1]-points[i-1][1])*part/4.0);
                    event(2,x,y,trace,start);
                }
                pause(settle*1000000L);
            } catch(InterruptedException e){status=1;message="cancelled";}
              catch(Exception e){status=2;message=e.toString();}
            finally {
                try{release(status!=0||cancelled.get(),lastX,lastY,trace,start);}
                catch(Exception e){status=2;message="release failed: "+e;}
                busy.set(false);
                try{reply(seq,status,trace,message);}catch(IOException ignored){}
            }
        }},"pad0-gesture").start();
    }
    void begin(final int seq,final int x,final int y,final int hold,final int maxMs) {
        if(pressed||!busy.compareAndSet(false,true)){
            try{reply(seq,2,Collections.<long[]>emptyList(),"gesture already active");}catch(IOException ignored){}return;
        }
        cancelled.set(false);activeGesture=seq;gestureStart=System.nanoTime();leaseEnd=gestureStart+maxMs*1000000L;
        new Thread(new Runnable(){public void run(){
            List<long[]> trace=new ArrayList<long[]>();int status=0;String message="begun:"+seq;
            try{event(0,x,y,trace,gestureStart);pause(hold*1000000L);}
            catch(Exception e){status=2;message=e.toString();try{release(true,lastX,lastY,trace,gestureStart);}catch(Exception ignored){}activeGesture=0;}
            finally{busy.set(false);try{reply(seq,status,trace,message);}catch(IOException ignored){}}
        }},"pad0-begin").start();
        Thread lease=new Thread(new Runnable(){public void run(){
            try{
                while(activeGesture==seq&&System.nanoTime()<leaseEnd)Thread.sleep(10);
                synchronized(Pad0Batch.this){
                    if(activeGesture==seq){cancelled.set(true);activeGesture=0;if(pressed)release(true,lastX,lastY,null,gestureStart);}
                }
            }catch(Exception ignored){}
        }},"pad0-lease");lease.setDaemon(true);lease.start();
    }
    void resume(final int seq,final int gesture,final int[][] points,final int settle,final int stepUs,final int cornerUs){
        if(!pressed||activeGesture!=gesture||cancelled.get()||System.nanoTime()>=leaseEnd||points[0][0]!=lastX||points[0][1]!=lastY||!busy.compareAndSet(false,true)){
            try{reply(seq,2,Collections.<long[]>emptyList(),"held gesture unavailable");}catch(IOException ignored){}return;
        }
        new Thread(new Runnable(){public void run(){
            List<long[]> trace=new ArrayList<long[]>();int status=0;String message="held:"+gesture;
            try{
                for(int i=1;i<points.length;i++)for(int part=1;part<=4;part++){
                    boolean corner=false;
                    if(part==1&&i>1){
                        long ax=points[i-1][0]-points[i-2][0],ay=points[i-1][1]-points[i-2][1];
                        long bx=points[i][0]-points[i-1][0],by=points[i][1]-points[i-1][1];
                        corner=ax*by!=ay*bx||ax*bx+ay*by<=0;
                    }
                    pause((corner?Math.max(stepUs,cornerUs):stepUs)*1000L);
                    if(activeGesture!=gesture||System.nanoTime()>=leaseEnd-80000000L)throw new IOException("gesture time budget exceeded");
                    int x=(int)Math.round(points[i-1][0]+(points[i][0]-points[i-1][0])*part/4.0);
                    int y=(int)Math.round(points[i-1][1]+(points[i][1]-points[i-1][1])*part/4.0);
                    event(2,x,y,trace,gestureStart);
                }
                pause(settle*1000000L);
                if(activeGesture!=gesture||System.nanoTime()>=leaseEnd-40000000L)throw new IOException("gesture time budget exceeded");
            }catch(Exception e){status=2;message=e.toString();cancelled.set(true);activeGesture=0;try{release(true,lastX,lastY,trace,gestureStart);}catch(Exception ignored){}}
            finally{busy.set(false);try{reply(seq,status,trace,message);}catch(IOException ignored){}}
        }},"pad0-resume").start();
    }
    synchronized void finish(int seq,int gesture) throws IOException {
        List<long[]> trace=new ArrayList<long[]>();int status=0;String message="released:"+gesture;
        try{
            if(!pressed||activeGesture!=gesture||busy.get()||cancelled.get()||System.nanoTime()>=leaseEnd)throw new IOException("held gesture unavailable");
            release(false,lastX,lastY,trace,gestureStart);activeGesture=0;
        }catch(Exception e){status=2;message=e.toString();cancelled.set(true);activeGesture=0;try{release(true,lastX,lastY,trace,gestureStart);}catch(Exception ignored){}}
        reply(seq,status,trace,message);
    }
    void validatePoint(int x,int y) throws IOException {
        if(x<0||x>=width||y<0||y>=height)throw new IOException("point outside display");
    }
    void serve(Socket socket,String token) throws Exception {
        socket.setTcpNoDelay(true);DataInputStream in=new DataInputStream(socket.getInputStream());
        output=new DataOutputStream(socket.getOutputStream());
        if(in.readInt()!=MAGIC||!token.equals(in.readUTF()))throw new IOException("session mismatch");
        width=in.readInt();height=in.readInt();if(width<1||height<1||width>16384||height>16384)throw new IOException("invalid size");
        output.writeInt(MAGIC);output.flush();
        try{while(true){
            int command=in.readInt(),seq=in.readInt();
            if(command==1){
                int count=in.readInt(),hold=in.readInt(),settle=in.readInt(),max=in.readInt(),step=in.readInt();
                if(count<1||count>66||hold<0||hold>1000||settle<0||settle>1000||max<100||max>15000||step<1000||step>100000)throw new IOException("invalid gesture");
                int[][] points=new int[count][2];
                for(int i=0;i<count;i++){
                    points[i][0]=in.readInt();points[i][1]=in.readInt();
                    if(points[i][0]<0||points[i][0]>=width||points[i][1]<0||points[i][1]>=height)throw new IOException("point outside display");
                }
                gesture(seq,points,hold,settle,max,step);
            }else if(command==2){
                in.readInt();in.readInt();cancelled.set(true);activeGesture=0;
                List<long[]> trace=new ArrayList<long[]>();long start=System.nanoTime();int status=0;String message="idle";
                synchronized(this){
                    // This connection owns its selected touchscreen/pointer 0. An idle
                    // cleanup is a state query, never an unpaired mouse/touch UP.
                    if(pressed){
                        message="released";
                        try{release(true,lastX,lastY,trace,start);}
                        catch(Exception e){status=2;message="owned touch release: "+e;}
                    }
                }
                reply(seq,status,trace,message);
            }else if(command==3){
                int x=in.readInt(),y=in.readInt(),hold=in.readInt(),max=in.readInt();validatePoint(x,y);
                if(hold<0||hold>1000||max<100||max>15000)throw new IOException("invalid held gesture");
                begin(seq,x,y,hold,max);
            }else if(command==4){
                int gesture=in.readInt(),count=in.readInt(),settle=in.readInt(),step=in.readInt(),corner=in.readInt();
                if(gesture<=0||count<2||count>66||settle<0||settle>1000||step<1000||step>100000||corner<step||corner>100000)throw new IOException("invalid continuation");
                int[][] points=new int[count][2];
                for(int i=0;i<count;i++){points[i][0]=in.readInt();points[i][1]=in.readInt();validatePoint(points[i][0],points[i][1]);}
                resume(seq,gesture,points,settle,step,corner);
            }else if(command==6){reply(seq,0,Collections.<long[]>emptyList(),"touchscreen:"+touchDevice);
            }else if(command==5){finish(seq,in.readInt());
            }else throw new IOException("unknown command");
        }}catch(EOFException expected){}finally{cancelled.set(true);activeGesture=0;if(pressed)release(true,lastX,lastY,null,System.nanoTime());}
    }
    public static void main(String[] args) throws Exception {
        Pad0Batch app=new Pad0Batch();int port=Integer.parseInt(args[0]);
        try(ServerSocket server=new ServerSocket(port,1,InetAddress.getByName("127.0.0.1"));Socket socket=server.accept()){
            app.serve(socket,args[1]);
        }
    }
}
