"""Bundle local feature modules for launchers that update one Python file.

Development imports normal modules. Only the generated release source embeds
compressed module sources, so an old launcher's verified update and its backup
are self-contained. No downloads, user data writes or source copying at startup.
"""
from __future__ import annotations

import ast
import base64
from pathlib import Path
import zlib

ROOT = Path(__file__).resolve().parents[1]
MODULES = ('pad0_common', 'pad0_quantity', 'pad0_crystal', 'pad0_crystal_review', 'pad0_input', 'pad0_solver', 'pad0_ai', 'pad0_ui')


def bundle_source(source: str, modules: dict[str, str]) -> str:
    tree = ast.parse(source)
    futures = [node for node in tree.body if isinstance(node, ast.ImportFrom) and node.module == '__future__']
    insertion = max((node.end_lineno for node in futures), default=0)
    # Reject invalid feature sources at build time, before producing an update.
    for name, code in modules.items():
        if not name.isidentifier(): raise ValueError('Invalid feature module name')
        compile(code, name + '.py', 'exec')
    payloads = {name: base64.b85encode(zlib.compress(code.encode('utf-8'), 9)).decode('ascii')
                for name, code in modules.items()}
    bootstrap = '''
# Generated release bundle: feature sources are maintained in separate files.
def _pad0_load_release_modules():
    import base64, sys, types, zlib
    from pathlib import Path
    payloads = %r
    for name, payload in payloads.items():
        module = types.ModuleType(name)
        module.__file__ = str(Path(__file__).with_name(name + '.py'))
        module.__package__ = ''
        sys.modules[name] = module
        try:
            exec(compile(zlib.decompress(base64.b85decode(payload)), module.__file__, 'exec'), module.__dict__)
        except BaseException:
            sys.modules.pop(name, None)
            raise
_pad0_load_release_modules()
del _pad0_load_release_modules

''' % payloads
    lines = source.splitlines(keepends=True)
    result = ''.join(lines[:insertion]) + bootstrap + ''.join(lines[insertion:])
    compile(result, 'pad0_overlay.py', 'exec')
    return result


def build_source(root: Path = ROOT) -> bytes:
    return bundle_source((root / 'pad0_overlay.py').read_text(encoding='utf-8'),
                         {name: (root / (name + '.py')).read_text(encoding='utf-8') for name in MODULES}).encode('utf-8')


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    args.output.write_bytes(build_source())
