"""Check a configured HTTPS release manifest, then run PAD0 with one instance."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from urllib.parse import urlsplit
from urllib.request import build_opener, HTTPRedirectHandler, Request


class UpdateError(ValueError):
    pass


def https_url(value):
    if not isinstance(value, str):
        raise UpdateError('An HTTPS URL is required.')
    parsed = urlsplit(value)
    if (parsed.scheme != 'https' or not parsed.hostname or parsed.username
            or parsed.password or parsed.fragment):
        raise UpdateError('Only HTTPS URLs without embedded credentials are allowed.')
    return value


class HTTPSRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        https_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def download(url, limit):
    request = Request(https_url(url), headers={'User-Agent': 'PAD0-Updater/1', 'Cache-Control': 'no-cache'})
    # Keep Python's default CA/certificate/hostname verification enabled.
    with build_opener(HTTPSRedirects()).open(request, timeout=5) as response:
        https_url(response.geturl())
        data = response.read(limit + 1)
    if len(data) > limit:
        raise UpdateError('Download exceeds the permitted size.')
    return data


def atomic_write(path, data):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix=path.name + '.', delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def check_for_update(base_dir, fetch=download):
    config_path = base_dir / 'update_config.json'
    if not config_path.exists():
        print('Update configuration absent; using installed program.', flush=True)
        return False
    config = json.loads(config_path.read_text(encoding='utf-8-sig'))
    if not config.get('manifest_url'):
        print('Update address is not configured; using installed program.', flush=True)
        return False
    manifest = json.loads(fetch(https_url(config['manifest_url']), 16 * 1024))
    release = manifest.get('release')
    digest = manifest.get('sha256', '')
    if (type(release) is not int or release < 1 or not isinstance(digest, str)
            or not re.fullmatch(r'[a-f0-9]{64}', digest)):
        raise UpdateError('Invalid release number or SHA-256 in manifest.')
    source_url = https_url(manifest.get('source_url'))
    state_path = base_dir / 'pad0_update_state.json'
    state = json.loads(state_path.read_text(encoding='utf-8')) if state_path.exists() else {}
    installed = state.get('release', 0)
    if type(installed) is not int or installed < 0:
        raise UpdateError('Invalid installed release state.')
    if release <= installed:
        print('No newer release available.', flush=True)
        return False
    source = fetch(source_url, 2 * 1024 * 1024)
    if hashlib.sha256(source).hexdigest() != digest:
        raise UpdateError('Source checksum mismatch; installed program retained.')
    if not source:
        raise UpdateError('Downloaded source is empty.')
    compile(source, 'pad0_overlay.py', 'exec')  # Validate without executing downloaded code.
    target = base_dir / 'pad0_overlay.py'
    if target.exists():
        previous = target.read_bytes()
        if previous != source:
            atomic_write(base_dir / 'pad0_overlay.py.bak', previous)
            atomic_write(target, source)
    else:
        atomic_write(target, source)
    atomic_write(state_path, json.dumps({'release': release, 'sha256': digest}).encode('utf-8'))
    print(f'Update release {release} installed.', flush=True)
    return True


def acquire_lock(base_dir):
    """The OS releases this lock on exit, including after a crash."""
    stream = (base_dir / '.pad0_running.lock').open('a+b')
    stream.seek(0, os.SEEK_END)
    if stream.tell() == 0:
        stream.write(b'0')
        stream.flush()
    stream.seek(0)
    try:
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        stream.close()
        return None
    return stream


def main(base_dir=None):
    base_dir = Path(base_dir) if base_dir is not None else Path(__file__).resolve().parent
    lock = acquire_lock(base_dir)
    if lock is None:
        print('PAD0 is already running; no update or second launch.', flush=True)
        return 0
    with lock:
        try:
            check_for_update(base_dir)
        except Exception as error:
            # Do not log URLs, which may contain private signed query parameters.
            print(f'Update failed ({type(error).__name__}); using installed program.', flush=True)
        target = base_dir / 'pad0_overlay.py'
        if not target.is_file():
            print('pad0_overlay.py is missing; cannot launch.', flush=True)
            return 2
        return subprocess.run([sys.executable, str(target)], cwd=base_dir).returncode


if __name__ == '__main__':
    raise SystemExit(main())
