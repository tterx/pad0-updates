@echo off
setlocal
cd /d "%~dp0"
echo Runs Pad0 Overlay v56 in a visible command window for troubleshooting.
echo Logs from the hidden launcher are in startup.log.
echo.
call run.bat
if errorlevel 1 echo The app exited with an error. See startup.log.
pause
