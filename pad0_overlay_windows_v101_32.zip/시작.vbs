Option Explicit
Dim shell, fso, baseDir
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
baseDir = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = baseDir
' Run hidden; run.bat redirects output and errors to startup.log.
shell.Run Chr(34) & baseDir & "\run.bat" & Chr(34), 0, False
Set fso = Nothing
Set shell = Nothing
