@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0logs" mkdir "%~dp0logs"
set "LOG=%~dp0logs\startup.log"
set "APP_DIR=%~dp0"
if exist "%~dp0app\pad0_launcher.py" set "APP_DIR=%~dp0app\"
call :main >> "%LOG%" 2>&1
exit /b %ERRORLEVEL%

:main
echo ============================================================
echo Pad0 Overlay startup: %DATE% %TIME%
echo Folder: %~dp0

echo Detecting Python...
set "PY_CMD="
where py >nul 2>&1
if not errorlevel 1 (
  py -3 --version >nul 2>&1
  if not errorlevel 1 set "PY_CMD=py -3"
)
if not defined PY_CMD (
  where python >nul 2>&1
  if not errorlevel 1 (
    python --version >nul 2>&1
    if not errorlevel 1 set "PY_CMD=python"
  )
)
if not defined PY_CMD (
  where python3 >nul 2>&1
  if not errorlevel 1 (
    python3 --version >nul 2>&1
    if not errorlevel 1 set "PY_CMD=python3"
  )
)
if not defined PY_CMD (
  echo ERROR: Python 3 was not found on PATH.
  echo Install Python 3.11 or later from https://www.python.org/downloads/windows/
  exit /b 2
)
echo Python command: %PY_CMD%
%PY_CMD% --version

%PY_CMD% -c "import mss, numpy, PIL, rapidocr, onnxruntime, cv2, maa.controller, MaaAgentBinary" >nul 2>&1
if errorlevel 1 (
  echo Required packages missing; installing requirements...
  %PY_CMD% -m pip install --disable-pip-version-check -r "%APP_DIR%requirements.txt"
  if errorlevel 1 (
    echo ERROR: dependency installation failed. See this log for details.
    exit /b 3
  )
)

echo Starting Pad0 Overlay...
%PY_CMD% "%APP_DIR%pad0_launcher.py"
set "APP_RC=%ERRORLEVEL%"
echo Application exited with code %APP_RC% at %DATE% %TIME%
exit /b %APP_RC%
