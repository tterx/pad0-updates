@echo off
setlocal
cd /d "%~dp0"
if exist "run.bat" (set "PAD0_START=run.bat") else (set "PAD0_START=..\run.bat")
echo PAD0 visible launch. Log: logs\startup.log in the installation folder.
call "%PAD0_START%"
if errorlevel 1 echo PAD0 exited with an error. See logs\startup.log.
pause
