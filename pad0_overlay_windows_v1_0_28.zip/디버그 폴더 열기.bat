@echo off
if not exist "%LOCALAPPDATA%\Pad0Overlay\debug" mkdir "%LOCALAPPDATA%\Pad0Overlay\debug"
start "" "%LOCALAPPDATA%\Pad0Overlay\debug"
